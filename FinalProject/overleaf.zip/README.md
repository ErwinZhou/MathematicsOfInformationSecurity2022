# 国家自然科学基金LaTeX模板

根据国家自然科学基金Word模板改造的，适合习惯用LaTex和对格式细节把控有些许洁癖的人士。建议在Windows平台下用TexLive和PDFLaTeX编译。Mac和Linux平台亲测可用（xeLatex或者luaLaTeX）。可以通过Overleaf在线预览：https://www.overleaf.com/read/jydxqkkkskzp

如果您有任何修改建议，可以联系：https://mmcheng.net
